<?php
// Redirect ke halaman login unified
header('Location: login.php');
exit();
?>
