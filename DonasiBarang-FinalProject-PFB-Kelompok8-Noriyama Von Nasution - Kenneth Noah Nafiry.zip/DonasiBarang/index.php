<?php
session_start();
require_once 'db.php';

// Ambil data donasi yang tersedia
// Pastikan query mengambil semua kolom (d.*) termasuk alamat jika sudah ditambahkan di database
$query = "SELECT d.*, u.nama as user_nama FROM donasi d JOIN users u ON d.user_id = u.id WHERE d.status = 'tersedia' ORDER BY d.tanggal DESC LIMIT 6";
$result = db_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donasi Barang - Platform Donasi</title>
    <link rel="stylesheet" href="style.css">
    
    <style>
        /* Style untuk Latar Belakang Gelap */
        .modal {
            display: none; /* Sembunyi default */
            position: fixed;
            z-index: 9999; /* Pastikan di paling depan */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.8); /* Warna hitam transparan */
            backdrop-filter: blur(4px); /* Efek blur di belakang */
        }

        /* Style untuk Kotak Konten Popup */
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto; /* Jarak dari atas */
            padding: 0;
            border-radius: 12px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
            position: relative;
            animation: slideDown 0.3s ease-out; /* Animasi muncul */
        }

        /* Animasi Turun dari Atas */
        @keyframes slideDown {
            from {top: -50px; opacity: 0;}
            to {top: 0; opacity: 1;}
        }

        /* Tombol Tutup (X) */
        .close-modal {
            color: white;
            position: absolute;
            right: 15px;
            top: 10px;
            font-size: 30px;
            font-weight: bold;
            cursor: pointer;
            z-index: 100;
            text-shadow: 0 0 5px rgba(0,0,0,0.5);
        }
        .close-modal:hover { color: #ff6b6b; }

        /* Area Gambar */
        .modal-image-container {
            width: 100%;
            height: 300px;
            background: #eee;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            border-radius: 12px 12px 0 0;
        }
        .modal-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Area Teks */
        .modal-body { padding: 25px; }
        .modal-title { 
            margin: 0 0 15px 0; 
            color: #333; 
            font-size: 1.8rem;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
        }
        .modal-info-group { margin-bottom: 15px; }
        .modal-label { 
            font-weight: bold; 
            color: #667eea; 
            display: block; 
            margin-bottom: 5px;
            font-size: 0.9rem;
            text-transform: uppercase;
        }
        .modal-text { color: #555; line-height: 1.6; }
        
        /* Box Khusus Alamat */
        .alamat-box {
            background: #f8f9fa;
            border-left: 5px solid #667eea;
            padding: 15px;
            border-radius: 4px;
            color: #333;
            font-weight: 500;
        }

        /* Agar kursor berubah saat menyentuh kartu */
        .donation-card { cursor: pointer; transition: transform 0.2s; }
        .donation-card:active { transform: scale(0.98); }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>Donasi Barang</h1>
            <p>Platform donasi barang untuk membantu sesama</p>
            
            <nav class="nav">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <span style="color: white; align-self: center; font-weight: bold; margin-right: 10px;">Halo, <?php echo htmlspecialchars($_SESSION['user_nama']); ?></span>
                    <a href="dashboard.php" class="btn btn-secondary">Dashboard</a>
                    <a href="logout.php" class="btn btn-secondary">Keluar</a>
                <?php elseif (isset($_SESSION['admin_id'])): ?>
                    <span style="color: white; align-self: center; font-weight: bold; margin-right: 10px;">Halo, Admin!</span>
                    <a href="admin_dashboard.php" class="btn btn-secondary">Panel Admin</a>
                    <a href="admin_logout.php" class="btn btn-secondary">Keluar</a>
                <?php else: ?>
                    <a href="login.php" class="btn btn-primary">Masuk</a>
                    <a href="register.php" class="btn btn-secondary">Daftar</a>
                <?php endif; ?>
            </nav>
        </header>

        <section class="hero">
            <h2>Berbagi Kebaikan</h2>
            <p>Donasikan barang layak pakai Anda. <strong>Klik pada kartu donasi</strong> di bawah untuk melihat detail lengkap dan alamat pengambilan.</p>
        </section>

        <section class="features">
            <div class="feature-card">
                <div class="feature-icon">📦</div>
                <h3>Donasi Mudah</h3>
                <p>Upload foto barang dan deskripsi dengan mudah</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🚚</div>
                <h3>Pengiriman Terpantau</h3>
                <p>Pantau status donasi Anda dari tersedia hingga tersalurkan</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">📷</div>
                <h3>Bukti Penyaluran</h3>
                <p>Dapatkan bukti foto saat barang donasi Anda telah disalurkan</p>
            </div>
        </section>

        <section class="how-it-works">
            <h2>Cara Kerja</h2>
            <div class="steps">
                <div class="step"><div class="step-number">1</div><h4>Daftar Akun</h4><p>Buat akun gratis untuk mulai berdonasi</p></div>
                <div class="step"><div class="step-number">2</div><h4>Upload Barang</h4><p>Foto dan deskripsikan barang</p></div>
                <div class="step"><div class="step-number">3</div><h4>Kirim Donasi</h4><p>Tandai barang sebagai dikirim</p></div>
                <div class="step"><div class="step-number">4</div><h4>Lihat Bukti</h4><p>Dapatkan bukti penyaluran</p></div>
            </div>
        </section>

        <section class="dashboard-content">
            <h2>Donasi Terbaru</h2>
            <?php if (db_num_rows($result) > 0): ?>
                <div class="donation-grid">
                    <?php while ($row = db_fetch($result)): ?>
                        <?php 
                            // Cek apakah kolom alamat ada isinya
                            // Jika user lama belum punya alamat, tampilkan pesan default
                            $alamat = (isset($row['alamat']) && $row['alamat'] != '') ? $row['alamat'] : 'Hubungi pemilik untuk detail alamat.';
                        ?>
                        
                        <div class="donation-card" 
                             onclick="openModal(this)"
                             data-nama="<?php echo htmlspecialchars($row['nama_barang']); ?>"
                             data-desc="<?php echo htmlspecialchars($row['deskripsi']); ?>"
                             data-user="<?php echo htmlspecialchars($row['user_nama']); ?>"
                             data-alamat="<?php echo htmlspecialchars($alamat); ?>"
                             data-foto="uploads/<?php echo htmlspecialchars($row['foto']); ?>">
                            
                            <div class="donation-image">
                                <?php if ($row['foto'] && file_exists('uploads/' . $row['foto'])): ?>
                                    <img src="uploads/<?php echo htmlspecialchars($row['foto']); ?>" alt="<?php echo htmlspecialchars($row['nama_barang']); ?>">
                                <?php else: ?>
                                    <div class="no-image">📦</div>
                                <?php endif; ?>
                            </div>
                            <div class="donation-info">
                                <h3><?php echo htmlspecialchars($row['nama_barang']); ?></h3>
                                <p class="description"><?php echo htmlspecialchars($row['deskripsi']); ?></p>
                                <p class="donor">Oleh: <?php echo htmlspecialchars($row['user_nama']); ?></p>
                                <span class="status-badge status-tersedia">Tersedia (Klik Detail)</span>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Belum ada donasi tersedia. Jadilah yang pertama berdonasi!</p>
                    <a href="register.php" class="btn btn-primary">Daftar Sekarang</a>
                </div>
            <?php endif; ?>
        </section>

        <footer class="footer">
            <p>&copy; 2024 Donasi Barang. Berbagi untuk sesama.</p>
        </footer>
    </div>

    <div id="detailModal" class="modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal()">&times;</span>
            
            <div class="modal-image-container">
                <img id="modalImg" src="" alt="Foto Barang" class="modal-img">
                <div id="modalNoImg" class="no-image" style="display:none; font-size: 5rem;">📦</div>
            </div>

            <div class="modal-body">
                <h2 id="modalTitle" class="modal-title">Nama Barang</h2>

                <div class="modal-info-group">
                    <span class="modal-label">👤 Donatur</span>
                    <div id="modalUser" class="modal-text">Nama Donatur</div>
                </div>

                <div class="modal-info-group">
                    <span class="modal-label">📝 Deskripsi</span>
                    <div id="modalDesc" class="modal-text">Keterangan barang...</div>
                </div>

                <div class="modal-info-group">
                    <span class="modal-label">📍 Alamat Pengambilan</span>
                    <div id="modalAlamat" class="modal-text alamat-box">...</div>
                </div>

                <div style="margin-top: 25px;">
                    <?php if (!isset($_SESSION['user_id']) && !isset($_SESSION['admin_id'])): ?>
                        <a href="login.php" class="btn btn-primary btn-block">Masuk untuk Mengambil</a>
                    <?php else: ?>
                        <button onclick="closeModal()" class="btn btn-secondary btn-block">Tutup</button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Fungsi Buka Modal
        function openModal(element) {
            console.log("Tombol diklik!"); // Cek di console browser jika error

            var nama = element.getAttribute('data-nama');
            var desc = element.getAttribute('data-desc');
            var user = element.getAttribute('data-user');
            var alamat = element.getAttribute('data-alamat');
            var foto = element.getAttribute('data-foto');

            document.getElementById('modalTitle').innerText = nama;
            document.getElementById('modalDesc').innerText = desc;
            document.getElementById('modalUser').innerText = user;
            document.getElementById('modalAlamat').innerText = alamat;

            var imgElement = document.getElementById('modalImg');
            var noImgElement = document.getElementById('modalNoImg');

            // Cek apakah foto valid
            if (foto && foto !== 'uploads/') {
                imgElement.src = foto;
                imgElement.style.display = 'block';
                noImgElement.style.display = 'none';
            } else {
                imgElement.style.display = 'none';
                noImgElement.style.display = 'flex';
            }

            // Tampilkan Modal
            var modal = document.getElementById('detailModal');
            modal.style.display = "block";
            document.body.style.overflow = "hidden"; // Matikan scroll background
        }

        // Fungsi Tutup Modal
        function closeModal() {
            var modal = document.getElementById('detailModal');
            modal.style.display = "none";
            document.body.style.overflow = "auto"; // Hidupkan scroll background
        }

        // Tutup jika klik di luar area modal
        window.onclick = function(event) {
            var modal = document.getElementById('detailModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>