-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 12 Des 2025 pada 14.54
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `donasi_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `donasi`
--

CREATE TABLE `donasi` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `nama_barang` varchar(150) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `bukti_penyaluran` varchar(255) DEFAULT NULL,
  `status` enum('tersedia','dikirim','tersalurkan') DEFAULT 'tersedia',
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `donasi`
--

INSERT INTO `donasi` (`id`, `user_id`, `nama_barang`, `deskripsi`, `alamat`, `foto`, `bukti_penyaluran`, `status`, `tanggal`) VALUES
(3, 4, 'Mainan Edukasi', 'Mainan edukatif usia 3-5 tahun.', NULL, 'contoh3.jpg', 'bukti1.jpg', 'tersalurkan', '2025-12-12 13:12:32'),
(4, 2, 'Sepatu Olahraga', 'Sepatu ukuran 42, masih sangat layak.', NULL, 'contoh4.jpg', NULL, 'tersedia', '2025-12-12 13:12:32'),
(6, 6, 'Pakaian', 'Bantu Saudara di sumatra', NULL, '1765545638_9149.jpg', 'bukti_1765545879_3668.jpg', 'tersalurkan', '2025-12-12 13:20:38'),
(7, 6, 'Celana', 'Sumatra barat', NULL, '1765545689_1196.jpg', NULL, 'tersedia', '2025-12-12 13:21:29'),
(9, 5, 'Pakaian', 'Aceh', 'Jalan cikarang 1 Jakarta timur', '', NULL, 'tersedia', '2025-12-12 13:38:38'),
(11, 7, 'Pakaian', 'Pakaian untuk saudara kita di sumatra', 'Jalan kebon jeruk 23', '1765547379_5888.jpg', 'bukti_1765547460_8110.jpg', 'tersalurkan', '2025-12-12 13:49:39');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('user','admin') DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `password`, `role`) VALUES
(1, 'Admin', 'admin@donasi.com', '0192023a7bbd73250516f069df18b500', 'admin'),
(2, 'Budi Santoso', 'budi@example.com', '9c5fa085ce256c7c598f6710584ab25d', 'user'),
(4, 'Andi Wijaya', 'andi@example.com', '03339dc0dff443f15c254baccde9bece', 'user'),
(5, 'kennethnoah', 'kenneth@gmail.com', '482c811da5d5b4bc6d497ffa98491e38', 'user'),
(6, 'noriyama', 'noriya@gmail.com', '482c811da5d5b4bc6d497ffa98491e38', 'user'),
(7, 'almo', 'almo@gmail.com', '482c811da5d5b4bc6d497ffa98491e38', 'user');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `donasi`
--
ALTER TABLE `donasi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `donasi`
--
ALTER TABLE `donasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `donasi`
--
ALTER TABLE `donasi`
  ADD CONSTRAINT `donasi_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
